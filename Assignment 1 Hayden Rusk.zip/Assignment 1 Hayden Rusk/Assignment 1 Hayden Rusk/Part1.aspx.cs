﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_1_Hayden_Rusk
{
    public partial class Part1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int age = Int32.Parse(TextBoxAge.Text);
            int MHR = (220 - age);
            int RHR = Int32.Parse(TextBoxResting.Text);
            int RHRminusMHR = (RHR - MHR);
            double HR = (RHRminusMHR * .60) + RHR;
            resultLabel.Text = Convert.ToString(HR);
        }
    }
}