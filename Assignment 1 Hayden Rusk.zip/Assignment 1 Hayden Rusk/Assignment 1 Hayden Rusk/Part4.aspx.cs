﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_1_Hayden_Rusk
{
    public partial class Part4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonCalc_Click(object sender, EventArgs e)
        {

            double price = Int32.Parse(TextBoxPrice.Text);
            double down = Int32.Parse(TextBoxDown.Text);
            double annual = Double.Parse(TextBoxRate.Text);
            double age = Int32.Parse(TextBoxAge.Text);
            double I = annual / 1200;
            double N = age * 12;
            
            double exponent = Math.Pow((1 + I), N);
            double addemup = ((price - down) * I * exponent) / (exponent - 1) ;
            //LabelResult.Text = exponent.ToString("0.0");
            LabelResult.Text = "$" + addemup.ToString("0.00") + " is your Monthly Payment.";


            

        }
    }
}