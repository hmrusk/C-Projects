﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_1_Hayden_Rusk
{
    public partial class Part3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonCalc_Click(object sender, EventArgs e)
        {

            string Name = TextBoxName.Text;
            double Quiz = 0;
            double assignment = 0;
            double midterm = 0;
            double final = 0;
            double Grade = 0;
            String letterGrade = "";
            

            Quiz = Int32.Parse(TextBoxQuiz.Text) * .15;
            assignment = Int32.Parse(TextBoxAssign.Text) * .40;
            midterm = Int32.Parse(TextBoxMid.Text) * .20;
            final = Int32.Parse(TextBoxFinal.Text) * .25;
            Grade = (Quiz + assignment + midterm + final);

            LabelScore.Text = (Name + " has an average grade of " + Convert.ToString(Grade));
            if( Grade >= 90)
            {
                LabelLetter.Text = "A";
            }else if(Grade >= 80)
            {
                LabelLetter.Text = "B";
            }
            else if (Grade >= 70)
            {
                LabelLetter.Text = "C";
            }
            else if (Grade >= 60)
            {
                LabelLetter.Text = "D";
            }
            else 
            {
                LabelLetter.Text = "F";
            }


        }
    }
}