﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_1_Hayden_Rusk
{
    public partial class Part2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonCalc_Click(object sender, EventArgs e)
        {
            
            string makeupPrice = "";
            string discountPrice = "";
            Console.WriteLine("taeaaefea");

            for (int i= 0; i < DropDownListMakeup.Items.Count; i++)
            {
                if (DropDownListMakeup.Items[i].Selected)
                {
                    makeupPrice = DropDownListMakeup.Items[i].Value;
                    Console.WriteLine(makeupPrice + "1");
                }
            }
            for (int i = 0; i < DropDownListDiscount.Items.Count; i++)
            {
                if (DropDownListDiscount.Items[i].Selected)
                {
                    discountPrice = DropDownListDiscount.Items[i].Value;
                    Console.WriteLine(discountPrice + "2");
                }
            }
            int convertMakeup = Int32.Parse(makeupPrice);
            //Console.WriteLine(convertMakeup + "3");
            double convertDiscount = Convert.ToDouble(discountPrice);
            //Console.WriteLine(convertDiscount + "4");
            double value = (convertMakeup * convertDiscount);
            double trueValue = (convertMakeup - value);
            LabelResult.Text = Convert.ToString(trueValue);


        

        }
    }
}