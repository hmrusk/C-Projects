﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;



namespace Assignment4_Hayden_Rusk_
{

    public partial class WebForm1 : System.Web.UI.Page
    {
      
        static object[] SQLvalues;
        

        string itemListKey = "itemListKey";
        List<string> itemList
        {
            get
            {
                if (Session[itemListKey] == null)
                    Session[itemListKey] = new List<string>();
                return (List<string>)Session[itemListKey];
            }
        }

        string dayListKey = "dayListKey";
        List<string> dayList
        {
            get
            {
                if (Session[dayListKey] == null)
                    Session[dayListKey] = new List<string>();
                return (List<string>)Session[dayListKey];
            }
        }
        string sTimeListKey = "sTimeListKey";
        List<string> sTimeList
        {
            get
            {
                if (Session[sTimeListKey] == null)
                    Session[sTimeListKey] = new List<string>();
                return (List<string>)Session[sTimeListKey];
            }
        }
        string courseListKey = "courseListKey";
        List<string> courseList
        {
            get
            {
                if (Session[courseListKey] == null)
                    Session[courseListKey] = new List<string>();
                return (List<string>)Session[courseListKey];
            }
        }
        string eTimeListKey = "eTimeListKey";
        List<string> eTimeList
        {
            get
            {
                if (Session[eTimeListKey] == null)
                    Session[eTimeListKey] = new List<string>();
                return (List<string>)Session[eTimeListKey];
            }
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            schBtn.Enabled = false;

        }

        protected void courseBtn_Click(object sender, EventArgs e)
        {

            var x = "";
            courseLbl.Text = itemList.Count.ToString();
            
            for (int j = 0; j < itemList.Count; j++)
            {
                if (courseDDL.SelectedValue == itemList[j] && itemList.Count != 0)
                {
                    itemList.RemoveAt(itemList.Count-1);
                    courseLbl.Text = "No repeating Classes";
                }
                
            }
            itemList.Add(courseDDL.SelectedValue);

            if (itemList.Count == 4)
            {
                courseLbl.Text = "Now Click the Schedule button to get a list of your classes Times";
                courseBtn.Enabled = false;
                schBtn.Enabled = true;
            }
            for (int i = 0; i < itemList.Count; i++)
            {
                x = x + itemList[i].ToString();
                courseLbl.Text = x;
            }


            }
        SqlConnection conn = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\Hayden\Desktop\Visual Studio Code\Assignment4(Hayden Rusk)\Courses.mdf;Integrated Security = True; Connect Timeout = 30");
        SqlCommand cmd;
        SqlDataReader dr;
        protected void schBtn_Click(object sender, EventArgs e)
        {
            SQLvalues = new object[50];
            var x = 0;
            for (x = 0; x < 4; x++)
            {
                conn.Open();
                var qry = "select * from Schedule where CourseNumber = @m";
                cmd = new SqlCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", itemList[x]);
                dr = cmd.ExecuteReader();
                if (dr.Read()){
                    courseList.Add(dr.GetValue(1).ToString());
                    dayList.Add(dr.GetValue(3).ToString());
                    sTimeList.Add(dr.GetValue(4).ToString());
                    eTimeList.Add(dr.GetValue(5).ToString());
                }

                conn.Close();   
            }
            checkOverlap();
        }
        public void checkOverlap()
        {

            for (int x = 0; x < 3; x++)
            {
                if (dayList[x].Contains(dayList[x+1])
                    && Int32.Parse(sTimeList[x]) >= Int32.Parse(sTimeList[x + 1])
                    && Int32.Parse(eTimeList[x]) <= Int32.Parse(eTimeList[x + 1]))
                {

                    courseLbl.Text = "false";
                }
                else
                {
                    for (int j = 0; j < 4; j++)
                    {
                        DataTable dt = new DataTable();

                        if (dt.Columns.Count == 0)
                        {
                            dt.Columns.Add("Courses 1", typeof(string));
                            dt.Columns.Add("Courses 2", typeof(string));
                            dt.Columns.Add("Courses 3", typeof(string));
                            dt.Columns.Add("Courses 4", typeof(string));


                        }
                        DataRow NewRow = dt.NewRow();
                        NewRow[0] = (courseList[0] + " " + dayList[0] + " " + sTimeList[0] + " " + eTimeList[0]);
                        NewRow[1] = (courseList[1] + " " + dayList[1] + " " + sTimeList[1] + " " + eTimeList[1]);
                        NewRow[2] = (courseList[2] + " " + dayList[2] + " " + sTimeList[2] + " " + eTimeList[2]);
                        NewRow[3] = (courseList[3] + " " + dayList[3] + " " + sTimeList[3] + " " + eTimeList[3]);
                        dt.Rows.Add(NewRow);
                        courseView.DataSource = dt;
                        courseView.DataBind();
                    }
                }
            }
            


        }
    }
}