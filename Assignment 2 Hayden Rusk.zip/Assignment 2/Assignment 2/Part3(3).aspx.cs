﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.OleDb;
using System.Data;

namespace Assignment_2
{
    public partial class Part3_3_ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             if (!IsPostBack)
          {

                

                /* OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                 string qry = "select CreditHours from Academics";
                 OleDbCommand cmd = new OleDbCommand(qry, conn);
                 OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                 DataTable dt = new DataTable();
                 da.Fill(dt);
                 DropDownList1.DataSource = dt;

                 DropDownList1.DataTextField = "CreditHours";
                 DropDownList1.DataValueField = "CreditHours";
                 DropDownList1.DataBind();
                 
              
                GridView1.DataSource = dt;
                GridView1.DataBind();*/
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "0")
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where CreditHours between 0 and 30";
                
                OleDbCommand cmd = new OleDbCommand(qry, conn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string CreditHours = dt.Select()[0].ItemArray[0].ToString();
                string CreditHours2 = dt.Select()[1].ItemArray[0].ToString();
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @m or StudentIDNumber = @n ";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);

                cmd2.Parameters.AddWithValue("@m", CreditHours.ToString());
                cmd2.Parameters.AddWithValue("@n", CreditHours2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                

                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();

            }
            else if (DropDownList1.SelectedValue == "1")
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where CreditHours between 31 and 60";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string CreditHours = dt.Select()[0].ItemArray[0].ToString();
                string CreditHours2 = dt.Select()[1].ItemArray[0].ToString();
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @m or StudentIDNumber = @n ";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);

                cmd2.Parameters.AddWithValue("@m", CreditHours.ToString());
                cmd2.Parameters.AddWithValue("@n", CreditHours2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();



            }
            else if (DropDownList1.SelectedValue == "2")
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where CreditHours between 61 and 90";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string CreditHours = dt.Select()[0].ItemArray[0].ToString();
                string CreditHours2 = dt.Select()[1].ItemArray[0].ToString();
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @m or StudentIDNumber = @n ";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);

                cmd2.Parameters.AddWithValue("@m", CreditHours.ToString());
                cmd2.Parameters.AddWithValue("@n", CreditHours2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();

            }
            else if (DropDownList1.SelectedValue == "3")
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where CreditHours between 91 and 120";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string CreditHours = dt.Select()[0].ItemArray[0].ToString();
                string CreditHours2 = dt.Select()[1].ItemArray[0].ToString();
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @m or StudentIDNumber = @n ";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);

                cmd2.Parameters.AddWithValue("@m", CreditHours.ToString());
                cmd2.Parameters.AddWithValue("@n", CreditHours2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();

            }
        }
    }
}