﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_2
{
    public partial class Part1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string type = DDLVehicle.SelectedValue;
            double Vtype = Convert.ToDouble(type);

            string txtbxText = daysBox.Text;
            double txtbxValue = Convert.ToDouble(txtbxText);

            double Math = (Vtype * txtbxValue);

            ResultLabel.Text = "$" + Math.ToString();

        }
    }
}