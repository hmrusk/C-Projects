﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.OleDb;
using System.Data;

namespace Assignment_2
{
    public partial class Part3_5_ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(double.Parse(TextBox1.Text) >=  3.89 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();




                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n ";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";

            }
            else if(double.Parse(TextBox1.Text) >= 3.23 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();





                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
               


                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else if (double.Parse(TextBox1.Text) >= 3.11 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();





                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                


                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }

            else if (double.Parse(TextBox1.Text) >= 2.61 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();
                string SIDN3 = dt.Select()[3].ItemArray[0].ToString();




                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2" +
                      " or StudentIDNumber  = @n3";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                cmd2.Parameters.AddWithValue("@n3", SIDN3.ToString());
             

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else if (double.Parse(TextBox1.Text) >= 2.51 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();
                string SIDN3 = dt.Select()[3].ItemArray[0].ToString();
                string SIDN4 = dt.Select()[4].ItemArray[0].ToString();




                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2" +
                      " or StudentIDNumber  = @n3" +
                       " or StudentIDNumber  = @n4";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                cmd2.Parameters.AddWithValue("@n3", SIDN3.ToString());
                cmd2.Parameters.AddWithValue("@n4", SIDN4.ToString());
                

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else if (double.Parse(TextBox1.Text) >= 2.46 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();
                string SIDN3 = dt.Select()[3].ItemArray[0].ToString();
                string SIDN4 = dt.Select()[4].ItemArray[0].ToString();
                string SIDN5 = dt.Select()[5].ItemArray[0].ToString();




                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2" +
                      " or StudentIDNumber  = @n3" +
                       " or StudentIDNumber  = @n4" +
                        " or StudentIDNumber  = @n5";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                cmd2.Parameters.AddWithValue("@n3", SIDN3.ToString());
                cmd2.Parameters.AddWithValue("@n4", SIDN4.ToString());
                cmd2.Parameters.AddWithValue("@n5", SIDN5.ToString());
               

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else if (double.Parse(TextBox1.Text) >= 2.35 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();
                string SIDN3 = dt.Select()[3].ItemArray[0].ToString();
                string SIDN4 = dt.Select()[4].ItemArray[0].ToString();
                string SIDN5 = dt.Select()[5].ItemArray[0].ToString();
                string SIDN6 = dt.Select()[6].ItemArray[0].ToString();




                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2" +
                      " or StudentIDNumber  = @n3" +
                       " or StudentIDNumber  = @n4" +
                        " or StudentIDNumber  = @n5" +
                         " or StudentIDNumber  = @n6";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                cmd2.Parameters.AddWithValue("@n3", SIDN3.ToString());
                cmd2.Parameters.AddWithValue("@n4", SIDN4.ToString());
                cmd2.Parameters.AddWithValue("@n5", SIDN5.ToString());
                cmd2.Parameters.AddWithValue("@n6", SIDN6.ToString());
                

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else if(double.Parse(TextBox1.Text) >= 0 && double.Parse(TextBox1.Text) <= 3.97)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select StudentIDNumber from Academics where GPA >= @m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", TextBox1.Text);



                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                string SIDN = dt.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt.Select()[2].ItemArray[0].ToString();
                string SIDN3 = dt.Select()[3].ItemArray[0].ToString();
                string SIDN4 = dt.Select()[4].ItemArray[0].ToString();
                string SIDN5 = dt.Select()[5].ItemArray[0].ToString();
                string SIDN6 = dt.Select()[6].ItemArray[0].ToString();
                string SIDN7 = dt.Select()[7].ItemArray[0].ToString();



                //Label1.Text = SIDN;
                string qry2 = "select FirstName, LastName from Information where StudentIDNumber = @n " +
                    " or StudentIDNumber  = @n1" +
                    " or StudentIDNumber  = @n2" +
                      " or StudentIDNumber  = @n3" +
                       " or StudentIDNumber  = @n4" +
                        " or StudentIDNumber  = @n5" +
                         " or StudentIDNumber  = @n6" +
                          " or StudentIDNumber  = @n7";
                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@n", SIDN.ToString());
                cmd2.Parameters.AddWithValue("@n1", SIDN1.ToString());
                cmd2.Parameters.AddWithValue("@n2", SIDN2.ToString());
                cmd2.Parameters.AddWithValue("@n3", SIDN3.ToString());
                cmd2.Parameters.AddWithValue("@n4", SIDN4.ToString());
                cmd2.Parameters.AddWithValue("@n5", SIDN5.ToString());
                cmd2.Parameters.AddWithValue("@n6", SIDN6.ToString());
                cmd2.Parameters.AddWithValue("@n7", SIDN7.ToString());

                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                GridView1.DataSource = dt2;
                GridView1.DataBind();
                Label1.Text = "";
            }
            else
            {
                Label1.Text = "no GPA's equal to or Greater then that value";
            }
        }
    }
}