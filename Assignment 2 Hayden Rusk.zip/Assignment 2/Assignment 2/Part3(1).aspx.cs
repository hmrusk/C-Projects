﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.OleDb;
using System.Data;

namespace Assignment_2
{
    public partial class Part3_1_ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           /* if (!IsPostBack)
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select distinct State from Information";
                OleDbCommand cmd = new OleDbCommand(qry, conn);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                DropDownList1.DataSource = dt;
                DropDownList1.DataTextField = "State";
                DropDownList1.DataValueField = "State";
                DropDownList1.DataBind();
            }*/

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            /*OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
            string qry = "select FirstName, LastName from Information where State = @s";

           
            OleDbCommand cmd = new OleDbCommand(qry, conn);
            cmd.Parameters.AddWithValue("@s", DropDownList1.SelectedValue);
            Label1.Text = DropDownList1.SelectedValue;
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();*/


        }
    }
}