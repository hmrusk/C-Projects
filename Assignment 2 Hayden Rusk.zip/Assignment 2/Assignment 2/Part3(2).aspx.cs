﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.OleDb;
using System.Data;

namespace Assignment_2
{
    public partial class Part3_2_ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue == "Computer Science")
            {


                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select MajorCode from Majors where MajorName =@m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", DropDownList1.SelectedValue);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                //OleDbConnection conn2 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                string MajorCode = dt.Select()[0].ItemArray[0].ToString();
                //string MajorCode1 = dt.Select()[1].ItemArray[0].ToString();
               // string MajorCode2 = dt.Select()[2].ItemArray[0].ToString();
                string qry2 = "select StudentIDNumber from Academics where MajorCode = @m";

                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@m", MajorCode.ToString());
                //cmd2.Parameters.AddWithValue("@n", MajorCode1.ToString());
               // cmd2.Parameters.AddWithValue("@b", MajorCode2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                //OleDbConnection conn3 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString);
                string SIDN = dt2.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt2.Select()[1].ItemArray[0].ToString();
                string SIDN2 = dt2.Select()[2].ItemArray[0].ToString();

                string qry3 = "SELECT FirstName, LastName FROM Information WHERE StudentIDNumber = @m or StudentIDNumber = @n or StudentIDNumber = @b";
                OleDbCommand cmd3 = new OleDbCommand(qry3, conn);

                cmd3.Parameters.AddWithValue("@m", SIDN.ToString());
                cmd3.Parameters.AddWithValue("@n", SIDN1.ToString());
                cmd3.Parameters.AddWithValue("@b", SIDN2.ToString());
                OleDbDataAdapter da3 = new OleDbDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                string FName = dt3.Select()[0].ItemArray[0].ToString();
                //int amt = (int)cmd3.ExecuteScalar();



                GridView1.DataSource = dt3;
                GridView1.DataBind();

            }else if(DropDownList1.SelectedValue == "Chemistry")
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select MajorCode from Majors where MajorName =@m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", DropDownList1.SelectedValue);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                //OleDbConnection conn2 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                string MajorCode = dt.Select()[0].ItemArray[0].ToString();
                //string MajorCode1 = dt.Select()[1].ItemArray[0].ToString();
                // string MajorCode2 = dt.Select()[2].ItemArray[0].ToString();
                string qry2 = "select StudentIDNumber from Academics where MajorCode = @m";

                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@m", MajorCode.ToString());
                //cmd2.Parameters.AddWithValue("@n", MajorCode1.ToString());
                // cmd2.Parameters.AddWithValue("@b", MajorCode2.ToString());
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                //OleDbConnection conn3 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString);
                string SIDN = dt2.Select()[0].ItemArray[0].ToString();
                string SIDN1 = dt2.Select()[1].ItemArray[0].ToString();
                //string SIDN2 = dt2.Select()[2].ItemArray[0].ToString();

                string qry3 = "SELECT FirstName, LastName FROM Information WHERE StudentIDNumber = @m or StudentIDNumber = @nb";
                OleDbCommand cmd3 = new OleDbCommand(qry3, conn);

                cmd3.Parameters.AddWithValue("@m", SIDN.ToString());
                cmd3.Parameters.AddWithValue("@n", SIDN1.ToString());
                //cmd3.Parameters.AddWithValue("@b", SIDN2.ToString());
                OleDbDataAdapter da3 = new OleDbDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                string FName = dt3.Select()[0].ItemArray[0].ToString();
                //int amt = (int)cmd3.ExecuteScalar();



                GridView1.DataSource = dt3;
                GridView1.DataBind();
            }


            else
            {
                OleDbConnection conn = new OleDbConnection(ConfigurationManager.ConnectionStrings["assignment2"].ConnectionString);
                string qry = "select MajorCode from Majors where MajorName =@m";

                OleDbCommand cmd = new OleDbCommand(qry, conn);
                cmd.Parameters.AddWithValue("@m", DropDownList1.SelectedValue);
                OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                //OleDbConnection conn2 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
                string MajorCode = dt.Select()[0].ItemArray[0].ToString();
               
                string qry2 = "select StudentIDNumber from Academics where MajorCode = @m";

                OleDbCommand cmd2 = new OleDbCommand(qry2, conn);
                cmd2.Parameters.AddWithValue("@m", MajorCode.ToString());
                
                OleDbDataAdapter da2 = new OleDbDataAdapter(cmd2);
                DataTable dt2 = new DataTable();
                da2.Fill(dt2);

                //OleDbConnection conn3 = new OleDbConnection(ConfigurationManager.ConnectionStrings["ConnectionString2"].ConnectionString);
                string SIDN = dt2.Select()[0].ItemArray[0].ToString();
                

                string qry3 = "SELECT FirstName, LastName FROM Information WHERE StudentIDNumber = @m";
                OleDbCommand cmd3 = new OleDbCommand(qry3, conn);

                cmd3.Parameters.AddWithValue("@m", SIDN.ToString());
                
                OleDbDataAdapter da3 = new OleDbDataAdapter(cmd3);
                DataTable dt3 = new DataTable();
                da3.Fill(dt3);
                string FName = dt3.Select()[0].ItemArray[0].ToString();
                //int amt = (int)cmd3.ExecuteScalar();



                GridView1.DataSource = dt3;
                GridView1.DataBind();

            }
        }
    }
}