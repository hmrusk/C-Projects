﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_2
{
    public partial class Part2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ResultBtn_Click(object sender, EventArgs e)
        {

            string stringHours = TextBoxHours.Text;
            double doubleHours = Convert.ToDouble(stringHours);

             if (doubleHours >= 12)
            {
                resultLabel.Text = "$18.00";
            }
            else if (doubleHours == 11)
            {
                resultLabel.Text = "$17.00";
            }
            else if (doubleHours == 10)
            {
                resultLabel.Text = "$15.50";
            }
            else if (doubleHours == 9)
            {
                resultLabel.Text = "$14.00";
            }
            else if (doubleHours == 8)
            {
                resultLabel.Text = "$12.50";
            }
            else if (doubleHours == 7)
            {
                resultLabel.Text = "$11.00";
            }
            else if (doubleHours == 6)
            {
                resultLabel.Text = "$9.50";
            }
            else if (doubleHours == 5)
            {
                resultLabel.Text = "$8.00";
            }
            else if (doubleHours == 4)
            {
                resultLabel.Text = "$6.50";
            }
            else if (doubleHours == 0)
            {
                resultLabel.Text = "Please Place the amount of hours you wish to stay";
            }
            else if (doubleHours <= 3)
            {
                resultLabel.Text = "$5.00";
            }
            
            else 
            {
                resultLabel.Text = "Please enter a whole number for the amout of numbers you wish to stay";
            }


        }
    }
}