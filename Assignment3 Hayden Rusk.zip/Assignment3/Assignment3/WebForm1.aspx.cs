﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Runtime.Serialization;
using System.Xml;
using System.Text;
using System.IO;



namespace Assignment3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            errorLbl.Text = "";
            string zipCode = txtBoxZip.Text;
            if (zipCode == "" || zipCode.Length < 5)
            {
                errorLbl.Text = "Please enter a valid zipcode";
            }
            else
            {
                NWS.ndfdXML weather = new NWS.ndfdXML();
                string latLonList = weather.LatLonListZipCode(zipCode);
                XmlDocument latLon = new XmlDocument();
                latLon.LoadXml(latLonList);
                string[] latLonArray = latLon.GetElementsByTagName("latLonList")[0].InnerText.Split(' ');
                TableRow tempRow = new TableRow();
                foreach (string s in latLonArray)
                {
                    decimal latitude = Decimal.Parse(s.Split(',')[0]);
                    decimal longitude = Decimal.Parse(s.Split(',')[1]);
                    string forecast = weather.NDFDgenByDay(latitude, longitude, DateTime.Today, "5", NWS.unitType.e, NWS.formatType.Item24hourly);
                    XmlDocument fiveDayForecast = new XmlDocument();
                    fiveDayForecast.LoadXml(forecast);

                    XmlNodeList MaxTemp = fiveDayForecast.GetElementsByTagName("temperature");
                    Response.Write("<table width= 300 %  border=2>");
                    int x = 0;
                    foreach (XmlNode t in MaxTemp)
                    {
                        if (t.Attributes["type"].Value.Equals("maximum"))
                        {
                            foreach (XmlNode v in t.ChildNodes)
                            {
                                if (v.Name.Equals("value"))
                                {
                                    Response.Write("<td>" + " " + v.InnerText + " " + "</td>");
                                    
                                    /* TableCell tempCell = new TableCell();
                                     tempCell.Text = "<td>" + " " + v.InnerText + " " + "</td>"[x];
                                     tempRow.Cells.Add(tempCell);*/

                                }
                            }
                        }
                    }
                    Response.Write("</tr>");
                    XmlNodeList image = fiveDayForecast.GetElementsByTagName("conditions-icon");
                    Response.Write("<tr>");
                    x = 0;
                    foreach (XmlNode g in image)
                    {
                        foreach (XmlNode i in g.ChildNodes)
                        {
                            if (i.Name.Equals("icon-link"))
                            {
                                Response.Write("<td><img src=\"" + i.InnerText + "\"/></td>");
                                
                                /* TableCell tempCell = new TableCell();
                                 tempCell.Text = "<td><img src=\"" + weatherImage + "\"/></td>"[x];
                                 tempRow.Cells.Add(tempCell);
                                 x++;*/
                            }
                        }
                    }
                    Response.Write("</tr>");
                    XmlNodeList TempMin = fiveDayForecast.GetElementsByTagName("temperature");
                    Response.Write("<tr>");
                    x = 0;
                    foreach (XmlNode t in TempMin)
                    {
                        if (t.Attributes["type"].Value.Equals("minimum"))
                        {
                            foreach (XmlNode v in t.ChildNodes)
                            {
                                if (v.Name.Equals("value"))
                                {
                                    Response.Write("<td>" + " " + v.InnerText + " " + "</td>");
                                   /* TableCell tempCell = new TableCell();
                                    tempCell.Text = "<td>" + " " + v.InnerText + " " + "</td>"[x];
                                    tempRow.Cells.Add(tempCell);
                                    x++;*/
                                }
                            }
                        }
                    }
                    Response.Write("</tr>");

                    XmlNodeList Desc = fiveDayForecast.GetElementsByTagName("weather");
                    Response.Write("<tr>");
                    x = 0;
                    foreach (XmlNode w in Desc)
                    {
                        foreach (XmlNode wc in w.ChildNodes)
                        {
                            if (wc != null)
                            {
                                if (wc.Name.Equals("weather-conditions"))
                                {
                                    
                                   /*TableCell tempCell = new TableCell();
                                   tempCell.Text = ("<td>" + wc.Attributes["weather-summary"].InnerText + "</td>"[x]);
                                   tempRow.Cells.Add(tempCell);
                                   */
                                   Response.Write("<td>" + wc.Attributes["weather-summary"].InnerText + "</td>");
                                  

                                    }
                                }
                            }
                        }
                        Response.Write("</tr>");
                        Response.Write("</table>");
                       // ResultTbl.Rows.Add(tempRow);
                    
                    }
                }

            }


        }
    }
